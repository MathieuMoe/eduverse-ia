using EduVerse.Core.Common;
using EduVerse.Core.Teaching;

namespace EduVerse.Tests;

public class TeacherCompanionRuleTests
{
    private static TeacherSnapshot Snapshot(bool risk = true) => new(
        "Laura",
        [
            new ClassDigest(1, "Maths 2B", "Mathematics", 18, risk ? 2 : 0, 62, "Comparing fractions",
                risk ? [new AtRiskStudent("leo-id", "Leo", 1, "Maths 2B", 2, 40)] : []),
            new ClassDigest(2, "Maths 3A", "Mathematics", 14, 0, 80, null, []),
        ],
        "/Teacher", "Classes");

    [Fact]
    public void Suggestions_point_at_the_students_most_worth_a_look()
    {
        var actions = TeacherCompanion.Suggest(Snapshot(), TeachLanguage.English);
        Assert.Equal(["student-leo-id"], actions.Select(a => a.Id));
        Assert.Equal("/Teacher/Class?id=1&student=leo-id", actions[0].Url);
        Assert.Contains("Leo", actions[0].Label, StringComparison.Ordinal);

        var calm = TeacherCompanion.Suggest(Snapshot(risk: false), TeachLanguage.English);
        Assert.Equal(["class-1"], calm.Select(a => a.Id));
        Assert.Equal("/Teacher/Class?id=1", calm[0].Url);
    }

    [Fact]
    public void Offline_assistant_recognises_the_usual_questions()
    {
        var s = Snapshot();
        var actions = TeacherCompanion.Suggest(s, TeachLanguage.Spanish);
        var risk = TeacherCompanion.Demo(s, actions, "¿Quién necesita ayuda?", TeachLanguage.Spanish);
        Assert.Equal(actions.Select(a => a.Id), risk.Actions);
        var progress = TeacherCompanion.Demo(s, actions, "¿Cómo van mis clases?", TeachLanguage.Spanish);
        Assert.Contains("32 alumnos en 2 clases", progress.Text, StringComparison.Ordinal);
        Assert.Contains("Maths 2B", progress.Text, StringComparison.Ordinal);
        var reteach = TeacherCompanion.Demo(s, actions, "¿Qué debería reforzar?", TeachLanguage.Spanish);
        Assert.Contains("Comparing fractions", reteach.Text, StringComparison.Ordinal);
        Assert.Contains("motor de IA", TeacherCompanion.Demo(s, actions, "¿Cuál es la capital de Francia?", TeachLanguage.Spanish).Text, StringComparison.Ordinal);
        Assert.StartsWith("Salut Laura !", TeacherCompanion.Greeting(s, TeachLanguage.French), StringComparison.Ordinal);
    }

    [Fact]
    public void Greeting_and_progress_are_honest_with_no_classes_yet()
    {
        var empty = new TeacherSnapshot("Laura", [], "/Teacher", "Classes");
        Assert.Contains("Create a class", TeacherCompanion.Greeting(empty, TeachLanguage.English), StringComparison.Ordinal);
        Assert.Contains("don't have any classes yet", TeacherCompanion.Progress(empty, TeachLanguage.English), StringComparison.Ordinal);
        Assert.Empty(TeacherCompanion.Suggest(empty, TeachLanguage.English));
    }

    [Fact]
    public void The_hardest_class_is_the_one_with_the_lowest_average_progress()
    {
        Assert.Equal("Maths 2B", Snapshot().HardestClass!.Name);
    }
}
