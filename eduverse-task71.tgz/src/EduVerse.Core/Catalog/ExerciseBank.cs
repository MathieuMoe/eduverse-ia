using EduVerse.Core.Common;

namespace EduVerse.Core.Catalog;

/// <summary>
/// Demo content for the Duolingo-style exercise kinds (<see cref="ExerciseKind"/>) that are mixed into Practice-mode
/// quizzes alongside classic multiple-choice questions. True/False now covers all 10 subjects (task #72); the other
/// three kinds (fill-the-blank, reorder, match) are filled in incrementally in later passes, starting with the
/// subjects where they fit most naturally (Language, ForeignLanguage — task #71).
/// </summary>
public static class ExerciseBank
{
    private sealed record TrueFalseItem(string Topic, int Difficulty, Text Prompt, bool Answer, Text Explanation);

    private static readonly IReadOnlyList<TrueFalseItem> MathTrueFalse =
    [
        new("math.compare", 1,
            Text.Of("7 is bigger than 4.|7 es más grande que 4.|7 est plus grand que 4.|7 és més gran que 4."),
            true,
            Text.Of("Yes: 7 comes after 4, so it's bigger.|Sí: 7 va después de 4, así que es más grande.|Oui : 7 vient après 4, donc c'est plus grand.|Sí: 7 va després de 4, així que és més gran.")),
        new("math.add", 1,
            Text.Of("3 + 4 = 8.|3 + 4 = 8.|3 + 4 = 8.|3 + 4 = 8."),
            false,
            Text.Of("No: 3 + 4 = 7, not 8.|No: 3 + 4 = 7, no 8.|Non : 3 + 4 = 7, pas 8.|No: 3 + 4 = 7, no 8.")),
        new("math.percent", 2,
            Text.Of("50% of 20 is 10.|El 50% de 20 es 10.|50 % de 20, c'est 10.|El 50% de 20 és 10."),
            true,
            Text.Of("Yes: 50% is half, and half of 20 is 10.|Sí: el 50% es la mitad, y la mitad de 20 es 10.|Oui : 50 % c'est la moitié, et la moitié de 20 c'est 10.|Sí: el 50% és la meitat, i la meitat de 20 és 10.")),
        new("math.integers", 2,
            Text.Of("-3 is bigger than -1.|-3 es más grande que -1.|-3 est plus grand que -1.|-3 és més gran que -1."),
            false,
            Text.Of("No: on the number line, -1 is to the right of -3, so -1 is bigger.|No: en la recta numérica, -1 está a la derecha de -3, así que -1 es más grande.|Non : sur la droite numérique, -1 est à droite de -3, donc -1 est plus grand.|No: a la recta numèrica, -1 està a la dreta de -3, així que -1 és més gran.")),
        new("math.pythagoras", 3,
            Text.Of("In a right triangle, the square of the hypotenuse equals the sum of the squares of the other two sides.|En un triángulo rectángulo, el cuadrado de la hipotenusa es igual a la suma de los cuadrados de los otros dos lados.|Dans un triangle rectangle, le carré de l'hypoténuse est égal à la somme des carrés des deux autres côtés.|En un triangle rectangle, el quadrat de la hipotenusa és igual a la suma dels quadrats dels altres dos costats."),
            true,
            Text.Of("Yes: that's the Pythagorean theorem, a² + b² = c².|Sí: es el teorema de Pitágoras, a² + b² = c².|Oui : c'est le théorème de Pythagore, a² + b² = c².|Sí: és el teorema de Pitàgores, a² + b² = c².")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> PhysicsTrueFalse =
    [
        new("physics.boiling", 1,
            Text.Of("Water boils at 100°C at sea level.|El agua hierve a 100°C al nivel del mar.|L'eau bout à 100°C au niveau de la mer.|L'aigua bull a 100°C al nivell del mar."),
            true,
            Text.Of("Yes: at normal atmospheric pressure, water's boiling point is 100°C.|Sí: a la presión atmosférica normal, el punto de ebullición del agua es 100°C.|Oui : à la pression atmosphérique normale, le point d'ébullition de l'eau est 100°C.|Sí: a la pressió atmosfèrica normal, el punt d'ebullició de l'aigua és 100°C.")),
        new("physics.orbit", 1,
            Text.Of("The Earth orbits the Sun.|La Tierra orbita alrededor del Sol.|La Terre tourne autour du Soleil.|La Terra orbita al voltant del Sol."),
            true,
            Text.Of("Yes: the Earth completes one orbit around the Sun roughly every 365 days.|Sí: la Tierra completa una vuelta alrededor del Sol cada 365 días aproximadamente.|Oui : la Terre fait un tour complet autour du Soleil en environ 365 jours.|Sí: la Terra completa una volta al voltant del Sol cada 365 dies aproximadament.")),
        new("physics.light_sound", 2,
            Text.Of("Light travels faster than sound.|La luz viaja más rápido que el sonido.|La lumière voyage plus vite que le son.|La llum viatja més ràpid que el so."),
            true,
            Text.Of("Yes: that's why you see lightning before you hear the thunder.|Sí: por eso se ve el relámpago antes de oír el trueno.|Oui : c'est pour ça qu'on voit l'éclair avant d'entendre le tonnerre.|Sí: per això es veu el llamp abans de sentir el tro.")),
        new("physics.vacuum_fall", 2,
            Text.Of("In a vacuum, a feather and a hammer fall at the same speed.|En el vacío, una pluma y un martillo caen a la misma velocidad.|Dans le vide, une plume et un marteau tombent à la même vitesse.|Al buit, una ploma i un martell cauen a la mateixa velocitat."),
            true,
            Text.Of("Yes: without air resistance, gravity accelerates every object equally, whatever its mass.|Sí: sin resistencia del aire, la gravedad acelera a todos los objetos por igual, sea cual sea su masa.|Oui : sans résistance de l'air, la gravité accélère tous les objets de la même façon, quelle que soit leur masse.|Sí: sense resistència de l'aire, la gravetat accelera tots els objectes per igual, sigui quina sigui la seva massa.")),
        new("physics.energy", 3,
            Text.Of("Energy can be created out of nothing.|La energía se puede crear de la nada.|L'énergie peut être créée à partir de rien.|L'energia es pot crear del no-res."),
            false,
            Text.Of("No: the law of conservation of energy says energy can only change form, never be created or destroyed.|No: la ley de conservación de la energía dice que la energía solo puede cambiar de forma, nunca crearse ni destruirse.|Non : la loi de conservation de l'énergie dit que l'énergie ne peut que changer de forme, jamais être créée ni détruite.|No: la llei de conservació de l'energia diu que l'energia només pot canviar de forma, mai crear-se ni destruir-se.")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> ChemistryTrueFalse =
    [
        new("chemistry.water", 1,
            Text.Of("Water is made of hydrogen and oxygen.|El agua está formada por hidrógeno y oxígeno.|L'eau est composée d'hydrogène et d'oxygène.|L'aigua està formada per hidrogen i oxigen."),
            true,
            Text.Of("Yes: a water molecule is H₂O — two hydrogen atoms and one oxygen atom.|Sí: una molécula de agua es H₂O, dos átomos de hidrógeno y uno de oxígeno.|Oui : une molécule d'eau est H₂O, deux atomes d'hydrogène et un d'oxygène.|Sí: una molècula d'aigua és H₂O, dos àtoms d'hidrogen i un d'oxigen.")),
        new("chemistry.salt", 1,
            Text.Of("Table salt is made of carbon and oxygen.|La sal de mesa está formada por carbono y oxígeno.|Le sel de table est composé de carbone et d'oxygène.|La sal de taula està formada per carboni i oxigen."),
            false,
            Text.Of("No: table salt (NaCl) is made of sodium and chlorine.|No: la sal de mesa (NaCl) está formada por sodio y cloro.|Non : le sel de table (NaCl) est composé de sodium et de chlore.|No: la sal de taula (NaCl) està formada per sodi i clor.")),
        new("chemistry.ice", 2,
            Text.Of("Ice is denser than liquid water.|El hielo es más denso que el agua líquida.|La glace est plus dense que l'eau liquide.|El gel és més dens que l'aigua líquida."),
            false,
            Text.Of("No: ice is less dense than liquid water, which is exactly why it floats.|No: el hielo es menos denso que el agua líquida, por eso flota.|Non : la glace est moins dense que l'eau liquide, c'est pour ça qu'elle flotte.|No: el gel és menys dens que l'aigua líquida, per això flota.")),
        new("chemistry.ph", 2,
            Text.Of("A pH of 7 is neutral.|Un pH de 7 es neutro.|Un pH de 7 est neutre.|Un pH de 7 és neutre."),
            true,
            Text.Of("Yes: pH 7 is neutral; below 7 is acidic, above 7 is basic.|Sí: el pH 7 es neutro; por debajo de 7 es ácido, por encima de 7 es básico.|Oui : le pH 7 est neutre ; en dessous de 7 c'est acide, au-dessus c'est basique.|Sí: el pH 7 és neutre; per sota de 7 és àcid, per sobre de 7 és bàsic.")),
        new("chemistry.protons", 3,
            Text.Of("Atoms of the same element always have the same number of protons.|Los átomos de un mismo elemento siempre tienen el mismo número de protones.|Les atomes d'un même élément ont toujours le même nombre de protons.|Els àtoms d'un mateix element sempre tenen el mateix nombre de protons."),
            true,
            Text.Of("Yes: the number of protons (the atomic number) is exactly what defines an element.|Sí: el número de protones (el número atómico) es precisamente lo que define a un elemento.|Oui : le nombre de protons (le numéro atomique) est précisément ce qui définit un élément.|Sí: el nombre de protons (el nombre atòmic) és precisament el que defineix un element.")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> BiologyTrueFalse =
    [
        new("biology.heart", 1,
            Text.Of("Humans have one heart.|Los humanos tenemos un corazón.|Les humains ont un cœur.|Els humans tenim un cor."),
            true,
            Text.Of("Yes: humans have a single heart, with four chambers.|Sí: los humanos tenemos un solo corazón, con cuatro cámaras.|Oui : les humains ont un seul cœur, avec quatre cavités.|Sí: els humans tenim un sol cor, amb quatre cavitats.")),
        new("biology.photosynthesis", 1,
            Text.Of("Plants make their own food using sunlight.|Las plantas fabrican su propio alimento usando la luz del sol.|Les plantes fabriquent leur propre nourriture grâce à la lumière du soleil.|Les plantes fabriquen el seu propi aliment fent servir la llum del sol."),
            true,
            Text.Of("Yes: that process is called photosynthesis.|Sí: ese proceso se llama fotosíntesis.|Oui : ce processus s'appelle la photosynthèse.|Sí: aquest procés s'anomena fotosíntesi.")),
        new("biology.bones", 2,
            Text.Of("Adults have more bones than babies.|Los adultos tienen más huesos que los bebés.|Les adultes ont plus d'os que les bébés.|Els adults tenen més ossos que els nadons."),
            false,
            Text.Of("No: babies are born with more bones, and some fuse together as they grow.|No: los bebés nacen con más huesos, y algunos se fusionan a medida que crecen.|Non : les bébés naissent avec plus d'os, et certains fusionnent en grandissant.|No: els nadons neixen amb més ossos, i alguns es fusionen a mesura que creixen.")),
        new("biology.cells", 2,
            Text.Of("All living things are made of cells.|Todos los seres vivos están formados por células.|Tous les êtres vivants sont constitués de cellules.|Tots els éssers vius estan formats per cèl·lules."),
            true,
            Text.Of("Yes: the cell is the basic unit of every living thing, from bacteria to humans.|Sí: la célula es la unidad básica de todo ser vivo, desde las bacterias hasta los humanos.|Oui : la cellule est l'unité de base de tout être vivant, des bactéries aux humains.|Sí: la cèl·lula és la unitat bàsica de tot ésser viu, des dels bacteris fins als humans.")),
        new("biology.dna", 3,
            Text.Of("DNA carries genetic information in humans.|El ADN contiene la información genética en los humanos.|L'ADN porte l'information génétique chez les humains.|L'ADN conté la informació genètica en els humans."),
            true,
            Text.Of("Yes: DNA stores the instructions that build and run every cell in the body.|Sí: el ADN guarda las instrucciones que construyen y hacen funcionar cada célula del cuerpo.|Oui : l'ADN stocke les instructions qui construisent et font fonctionner chaque cellule du corps.|Sí: l'ADN guarda les instruccions que construeixen i fan funcionar cada cèl·lula del cos.")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> HistoryTrueFalse =
    [
        new("history.pyramids", 1,
            Text.Of("The pyramids of Egypt were built by the Romans.|Las pirámides de Egipto fueron construidas por los romanos.|Les pyramides d'Égypte ont été construites par les Romains.|Les piràmides d'Egipte van ser construïdes pels romans."),
            false,
            Text.Of("No: the pyramids were built by the ancient Egyptians, long before Rome existed.|No: las pirámides fueron construidas por los antiguos egipcios, mucho antes de que existiera Roma.|Non : les pyramides ont été construites par les anciens Égyptiens, bien avant que Rome n'existe.|No: les piràmides van ser construïdes pels antics egipcis, molt abans que existís Roma.")),
        new("history.ww2", 2,
            Text.Of("World War II ended in 1945.|La Segunda Guerra Mundial terminó en 1945.|La Seconde Guerre mondiale s'est terminée en 1945.|La Segona Guerra Mundial va acabar el 1945."),
            true,
            Text.Of("Yes: the war ended in 1945, with Germany surrendering in May and Japan in September.|Sí: la guerra terminó en 1945, con la rendición de Alemania en mayo y la de Japón en septiembre.|Oui : la guerre s'est terminée en 1945, avec la capitulation de l'Allemagne en mai et celle du Japon en septembre.|Sí: la guerra va acabar el 1945, amb la rendició d'Alemanya al maig i la del Japó al setembre.")),
        new("history.columbus", 2,
            Text.Of("Christopher Columbus was the first person to reach the Americas.|Cristóbal Colón fue la primera persona en llegar a América.|Christophe Colomb a été la première personne à atteindre les Amériques.|Cristòfor Colom va ser la primera persona a arribar a Amèrica."),
            false,
            Text.Of("No: Indigenous peoples had already lived in the Americas for thousands of years before Columbus arrived.|No: los pueblos indígenas ya vivían en América desde hacía miles de años antes de que llegara Colón.|Non : les peuples autochtones vivaient déjà en Amérique depuis des milliers d'années avant l'arrivée de Colomb.|No: els pobles indígenes ja vivien a Amèrica des de feia milers d'anys abans que hi arribés Colom.")),
        new("history.berlin_wall", 2,
            Text.Of("The Berlin Wall fell in 1989.|El Muro de Berlín cayó en 1989.|Le mur de Berlin est tombé en 1989.|El Mur de Berlín va caure el 1989."),
            true,
            Text.Of("Yes: the Berlin Wall fell in November 1989, a key moment in the end of the Cold War.|Sí: el Muro de Berlín cayó en noviembre de 1989, un momento clave en el fin de la Guerra Fría.|Oui : le mur de Berlin est tombé en novembre 1989, un moment clé de la fin de la guerre froide.|Sí: el Mur de Berlín va caure el novembre de 1989, un moment clau en la fi de la Guerra Freda.")),
        new("history.french_revolution", 3,
            Text.Of("The French Revolution began in 1789.|La Revolución Francesa comenzó en 1789.|La Révolution française a commencé en 1789.|La Revolució Francesa va començar el 1789."),
            true,
            Text.Of("Yes: it began in 1789, with the storming of the Bastille in July.|Sí: comenzó en 1789, con la toma de la Bastilla en julio.|Oui : elle a commencé en 1789, avec la prise de la Bastille en juillet.|Sí: va començar el 1789, amb la presa de la Bastilla al juliol.")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> GeographyTrueFalse =
    [
        new("geography.paris", 1,
            Text.Of("Paris is the capital of France.|París es la capital de Francia.|Paris est la capitale de la France.|París és la capital de França."),
            true,
            Text.Of("Yes: Paris has been France's capital for centuries.|Sí: París es la capital de Francia desde hace siglos.|Oui : Paris est la capitale de la France depuis des siècles.|Sí: París és la capital de França des de fa segles.")),
        new("geography.continent", 1,
            Text.Of("Africa is the largest continent.|África es el continente más grande.|L'Afrique est le plus grand continent.|L'Àfrica és el continent més gran."),
            false,
            Text.Of("No: Asia is the largest continent; Africa is the second largest.|No: Asia es el continente más grande; África es el segundo más grande.|Non : l'Asie est le plus grand continent ; l'Afrique est le deuxième.|No: Àsia és el continent més gran; l'Àfrica és el segon més gran.")),
        new("geography.amazon", 2,
            Text.Of("The Amazon rainforest is located in South America.|La selva amazónica está ubicada en Sudamérica.|La forêt amazonienne se trouve en Amérique du Sud.|La selva amazònica es troba a Sud-amèrica."),
            true,
            Text.Of("Yes: the Amazon spans several South American countries, mostly Brazil.|Sí: el Amazonas se extiende por varios países sudamericanos, sobre todo Brasil.|Oui : l'Amazonie s'étend sur plusieurs pays d'Amérique du Sud, surtout le Brésil.|Sí: l'Amazones s'estén per diversos països sud-americans, sobretot el Brasil.")),
        new("geography.pacific", 2,
            Text.Of("The Pacific is the largest ocean on Earth.|El Pacífico es el océano más grande de la Tierra.|Le Pacifique est le plus grand océan de la Terre.|El Pacífic és l'oceà més gran de la Terra."),
            true,
            Text.Of("Yes: the Pacific Ocean covers more area than any other ocean.|Sí: el océano Pacífico cubre más superficie que cualquier otro océano.|Oui : l'océan Pacifique couvre plus de surface que tout autre océan.|Sí: l'oceà Pacífic cobreix més superfície que qualsevol altre oceà.")),
        new("geography.everest", 3,
            Text.Of("Mount Everest is the tallest mountain on Earth, measured from sea level.|El Everest es la montaña más alta de la Tierra, medida desde el nivel del mar.|L'Everest est la plus haute montagne de la Terre, mesurée depuis le niveau de la mer.|L'Everest és la muntanya més alta de la Terra, mesurada des del nivell del mar."),
            true,
            Text.Of("Yes: at 8,849 meters above sea level, Everest is the highest point on Earth.|Sí: con 8.849 metros sobre el nivel del mar, el Everest es el punto más alto de la Tierra.|Oui : avec 8 849 mètres au-dessus du niveau de la mer, l'Everest est le point le plus haut de la Terre.|Sí: amb 8.849 metres sobre el nivell del mar, l'Everest és el punt més alt de la Terra.")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> EconomicsTrueFalse =
    [
        new("economics.scarcity", 1,
            Text.Of("Scarcity means there's an unlimited supply of resources.|La escasez significa que hay una oferta ilimitada de recursos.|La rareté signifie qu'il existe une offre illimitée de ressources.|L'escassetat significa que hi ha una oferta il·limitada de recursos."),
            false,
            Text.Of("No: scarcity means resources are limited compared to what people want.|No: la escasez significa que los recursos son limitados en comparación con lo que la gente quiere.|Non : la rareté signifie que les ressources sont limitées par rapport à ce que les gens veulent.|No: l'escassetat significa que els recursos són limitats en comparació amb el que la gent vol.")),
        new("economics.supply", 2,
            Text.Of("When supply increases and demand stays the same, prices tend to fall.|Cuando la oferta aumenta y la demanda se mantiene igual, los precios tienden a bajar.|Quand l'offre augmente et que la demande reste la même, les prix ont tendance à baisser.|Quan l'oferta augmenta i la demanda es manté igual, els preus tendeixen a baixar."),
            true,
            Text.Of("Yes: more supply with the same demand usually pushes prices down.|Sí: más oferta con la misma demanda suele hacer bajar los precios.|Oui : plus d'offre avec la même demande fait généralement baisser les prix.|Sí: més oferta amb la mateixa demanda sol fer baixar els preus.")),
        new("economics.inflation", 2,
            Text.Of("Inflation means prices are falling over time.|La inflación significa que los precios bajan con el tiempo.|L'inflation signifie que les prix baissent avec le temps.|La inflació significa que els preus baixen amb el temps."),
            false,
            Text.Of("No: inflation means prices are rising over time, so money buys less.|No: la inflación significa que los precios suben con el tiempo, así que el dinero compra menos.|Non : l'inflation signifie que les prix augmentent avec le temps, donc l'argent achète moins.|No: la inflació significa que els preus pugen amb el temps, així que els diners compren menys.")),
        new("economics.central_bank", 2,
            Text.Of("A country's central bank can set interest rates.|El banco central de un país puede fijar los tipos de interés.|La banque centrale d'un pays peut fixer les taux d'intérêt.|El banc central d'un país pot fixar els tipus d'interès."),
            true,
            Text.Of("Yes: setting interest rates is one of a central bank's main tools.|Sí: fijar los tipos de interés es una de las principales herramientas de un banco central.|Oui : fixer les taux d'intérêt est l'un des principaux outils d'une banque centrale.|Sí: fixar els tipus d'interès és una de les principals eines d'un banc central.")),
        new("economics.gdp", 3,
            Text.Of("GDP measures the total value of goods and services produced in a country.|El PIB mide el valor total de los bienes y servicios producidos en un país.|Le PIB mesure la valeur totale des biens et services produits dans un pays.|El PIB mesura el valor total dels béns i serveis produïts en un país."),
            true,
            Text.Of("Yes: Gross Domestic Product adds up the value of everything produced in a country, usually per year.|Sí: el Producto Interior Bruto suma el valor de todo lo producido en un país, normalmente por año.|Oui : le Produit intérieur brut additionne la valeur de tout ce qui est produit dans un pays, en général par an.|Sí: el Producte Interior Brut suma el valor de tot el que es produeix en un país, normalment per any.")),
    ];

    private static readonly IReadOnlyList<TrueFalseItem> ProgrammingTrueFalse =
    [
        new("programming.loop", 1,
            Text.Of("A loop lets code repeat multiple times.|Un bucle permite que el código se repita varias veces.|Une boucle permet au code de se répéter plusieurs fois.|Un bucle permet que el codi es repeteixi diverses vegades."),
            true,
            Text.Of("Yes: loops (like 'for' or 'while') run the same code again without rewriting it each time.|Sí: los bucles (como 'for' o 'while') ejecutan el mismo código otra vez sin tener que reescribirlo cada vez.|Oui : les boucles (comme 'for' ou 'while') exécutent le même code à nouveau sans le réécrire à chaque fois.|Sí: els bucles (com 'for' o 'while') executen el mateix codi una altra vegada sense haver-lo de reescriure cada cop.")),
        new("programming.variable", 1,
            Text.Of("A variable can only ever store one value for the whole life of a program.|Una variable solo puede almacenar un valor durante toda la vida de un programa.|Une variable ne peut stocker qu'une seule valeur pendant toute la vie d'un programme.|Una variable només pot emmagatzemar un valor durant tota la vida d'un programa."),
            false,
            Text.Of("No: a variable's value can be changed (reassigned) as many times as the program needs.|No: el valor de una variable se puede cambiar (reasignar) tantas veces como el programa necesite.|Non : la valeur d'une variable peut être modifiée (réaffectée) autant de fois que le programme en a besoin.|No: el valor d'una variable es pot canviar (reassignar) tantes vegades com el programa necessiti.")),
        new("programming.bug", 2,
            Text.Of("A \"bug\" in programming is a mistake that makes a program behave incorrectly.|Un \"bug\" en programación es un error que hace que un programa se comporte de forma incorrecta.|Un \"bug\" en programmation est une erreur qui fait que le programme se comporte mal.|Un \"bug\" en programació és un error que fa que un programa es comporti de manera incorrecta."),
            true,
            Text.Of("Yes: a bug is any mistake in the code that causes unexpected or wrong behavior.|Sí: un bug es cualquier error en el código que provoca un comportamiento inesperado o incorrecto.|Oui : un bug est toute erreur dans le code qui provoque un comportement inattendu ou incorrect.|Sí: un bug és qualsevol error en el codi que provoca un comportament inesperat o incorrecte.")),
        new("programming.binary", 2,
            Text.Of("Computers store data internally using only 0s and 1s.|Los ordenadores almacenan los datos internamente usando solo 0 y 1.|Les ordinateurs stockent les données en interne en utilisant seulement des 0 et des 1.|Els ordinadors emmagatzemen les dades internament fent servir només 0 i 1."),
            true,
            Text.Of("Yes: that's binary code — every piece of data a computer handles is ultimately 0s and 1s.|Sí: eso es el código binario; todo dato que maneja un ordenador es, en el fondo, 0 y 1.|Oui : c'est le code binaire ; toute donnée qu'un ordinateur traite est, au fond, des 0 et des 1.|Sí: això és el codi binari; tota dada que gestiona un ordinador és, al fons, 0 i 1.")),
        new("programming.html", 3,
            Text.Of("HTML is a programming language.|HTML es un lenguaje de programación.|HTML est un langage de programmation.|HTML és un llenguatge de programació."),
            false,
            Text.Of("No: HTML is a markup language — it describes a page's structure, but it can't do logic like loops or conditions on its own.|No: HTML es un lenguaje de marcado; describe la estructura de una página, pero no puede hacer lógica como bucles o condiciones por sí solo.|Non : HTML est un langage de balisage ; il décrit la structure d'une page, mais ne peut pas faire de logique comme des boucles ou des conditions à lui seul.|No: HTML és un llenguatge de marcatge; descriu l'estructura d'una pàgina, però no pot fer lògica com bucles o condicions per si sol.")),
    ];

    private static readonly Dictionary<Area, IReadOnlyList<TrueFalseItem>> Banks = new()
    {
        [Area.Mathematics] = MathTrueFalse,
        [Area.Physics] = PhysicsTrueFalse,
        [Area.Chemistry] = ChemistryTrueFalse,
        [Area.Biology] = BiologyTrueFalse,
        [Area.History] = HistoryTrueFalse,
        [Area.Geography] = GeographyTrueFalse,
        [Area.Economics] = EconomicsTrueFalse,
        [Area.Programming] = ProgrammingTrueFalse,
    };

    /// <summary>The 3 difficulty tiers every bank is organized into, from a subject's level.</summary>
    private static int DifficultyFor(Level level) => level switch
    {
        Level.EarlyYears or Level.Primary1 or Level.Primary2 => 1,
        Level.Primary3 or Level.Secondary1 => 2,
        _ => 3,
    };

    /// <summary>A true/false drill for the given subject and level, or null if the bank has none yet
    /// (today: Language and ForeignLanguage, where fill-blank/reorder/match fit more naturally — task #71).</summary>
    public static PracticeExercise? TrueFalse(Area area, Level level, TeachLanguage language, int seed)
    {
        if (!Banks.TryGetValue(area, out var bank))
        {
            return null;
        }

        var pool = bank.Where(i => i.Difficulty == DifficultyFor(level)).ToList();
        if (pool.Count == 0)
        {
            return null;
        }

        var item = pool[new Random(seed).Next(pool.Count)];
        return new PracticeExercise(item.Topic, item.Difficulty, ExerciseKind.TrueFalse, item.Prompt.In(language), item.Explanation.In(language))
        {
            CorrectBool = item.Answer,
        };
    }

    // ---- Language & ForeignLanguage: fill-blank, reorder and match (task #71) ----

    /// <summary>"English" / "Spanish" etc., in the student's own interface language — the only two foreign-language
    /// targets this app teaches (<see cref="QuestionBanks.ForeignTarget"/>).</summary>
    private static string TargetName(TeachLanguage language) =>
        (QuestionBanks.ForeignTarget(language) == TeachLanguage.English
            ? Text.Of("English|inglés|anglais|anglès")
            : Text.Of("Spanish|español|espagnol|castellà")).In(language);

    /// <summary>Fisher-Yates, seeded so the same drill always looks the same way (the student submits by text, not
    /// position, so a different shuffle between two views of the same drill — e.g. a page reload — is harmless).</summary>
    private static List<string> Shuffled(IReadOnlyList<string> items, int seed)
    {
        var copy = items.ToList();
        var rng = new Random(seed);
        for (var i = copy.Count - 1; i > 0; i--)
        {
            var j = rng.Next(i + 1);
            (copy[i], copy[j]) = (copy[j], copy[i]);
        }
        return copy;
    }

    private sealed record FillBlankItem(string Topic, int Difficulty, Text Prompt, Text Answer, Text Explanation);

    private static readonly IReadOnlyList<FillBlankItem> LanguageFillBlank =
    [
        new("language.opposites", 1,
            Text.Of("The opposite of \"hot\" is ___.|Lo contrario de \"caliente\" es ___.|Le contraire de « chaud » est ___.|El contrari de \"calent\" és ___."),
            Text.Of("cold|frío|froid|fred"),
            Text.Of("\"Cold\" is the opposite of \"hot\".|\"Frío\" es lo contrario de \"caliente\".|« Froid » est le contraire de « chaud ».|\"Fred\" és el contrari de \"calent\".")),
        new("language.parts_of_speech", 2,
            Text.Of("A word that describes a noun is called an ___.|Una palabra que describe a un sustantivo se llama ___.|Un mot qui décrit un nom s'appelle un ___.|Una paraula que descriu un nom s'anomena ___."),
            Text.Of("adjective|adjetivo|adjectif|adjectiu"),
            Text.Of("Words like \"blue\" or \"tall\" that describe a noun are adjectives.|Palabras como \"azul\" o \"alto\" que describen un sustantivo son adjetivos.|Des mots comme « bleu » ou « grand » qui décrivent un nom sont des adjectifs.|Paraules com \"blau\" o \"alt\" que descriuen un nom són adjectius.")),
        new("language.literary_devices", 3,
            Text.Of("When a writer compares two things using \"like\" or \"as\", it's called a ___.|Cuando un escritor compara dos cosas usando \"como\", se llama ___.|Quand un auteur compare deux choses avec « comme », on appelle ça une ___.|Quan un escriptor compara dues coses fent servir \"com\", se'n diu ___."),
            Text.Of("simile|símil|comparaison|símil"),
            Text.Of("\"As brave as a lion\" compares two things with \"as\": that's a simile.|\"Tan valiente como un león\" compara dos cosas con \"como\": eso es un símil.|« Aussi courageux qu'un lion » compare deux choses avec « comme » : c'est une comparaison.|\"Tan valent com un lleó\" compara dues coses amb \"com\": això és un símil.")),
    ];

    private static readonly IReadOnlyList<FillBlankItem> ForeignFillBlankWords =
    [
        new("foreign.vocabulary", 1, Text.Of("dog|perro|chien|gos"), Text.Of("dog|perro|chien|gos"), Text.Of("")),
        new("foreign.vocabulary", 2, Text.Of("house|casa|maison|casa"), Text.Of("house|casa|maison|casa"), Text.Of("")),
        new("foreign.vocabulary", 3, Text.Of("friend|amigo|ami|amic"), Text.Of("friend|amigo|ami|amic"), Text.Of("")),
    ];

    private static readonly Text ForeignFillBlankPrompt =
        Text.Of("How do you say \"{0}\" in {1}?|¿Cómo se dice \"{0}\" en {1}?|Comment dit-on « {0} » en {1} ?|Com es diu «{0}» en {1}?");

    private static readonly Text ForeignFillBlankExplanation =
        Text.Of("\"{0}\" in {1} is \"{2}\".|\"{0}\" en {1} es \"{2}\".|« {0} » en {1} se dit « {2} ».|\"{0}\" en {1} és \"{2}\".");

    /// <summary>A fill-in-the-blank drill, or null if the bank has none for this subject/level.</summary>
    public static PracticeExercise? FillBlank(Area area, Level level, TeachLanguage language, int seed)
    {
        var difficulty = DifficultyFor(level);
        if (area == Area.Language)
        {
            var pool = LanguageFillBlank.Where(i => i.Difficulty == difficulty).ToList();
            if (pool.Count == 0)
            {
                return null;
            }

            var item = pool[new Random(seed).Next(pool.Count)];
            return new PracticeExercise(item.Topic, item.Difficulty, ExerciseKind.FillBlank, item.Prompt.In(language), item.Explanation.In(language))
            {
                Answer = item.Answer.In(language),
            };
        }

        if (area == Area.ForeignLanguage)
        {
            var pool = ForeignFillBlankWords.Where(i => i.Difficulty == difficulty).ToList();
            if (pool.Count == 0)
            {
                return null;
            }

            var word = pool[new Random(seed).Next(pool.Count)];
            var target = QuestionBanks.ForeignTarget(language);
            var targetName = TargetName(language);
            var sourceWord = word.Answer.In(language); // the "Answer" field doubles as the word concept here
            var targetWord = word.Answer.In(target);
            return new PracticeExercise(word.Topic, word.Difficulty, ExerciseKind.FillBlank,
                ForeignFillBlankPrompt.Format(language, sourceWord, targetName),
                ForeignFillBlankExplanation.Format(language, sourceWord, targetName, targetWord))
            {
                Answer = targetWord,
            };
        }

        return null;
    }

    // Each language's sentence is kept whole (not word-aligned across languages, since a translation rarely has the
    // same word count) and split into tokens at build time by Reorder() — see TokensOf.
    private sealed record ReorderItem(string Topic, int Difficulty, Text Prompt, Text Sentence, Text Explanation);

    private static string[] TokensOf(Text sentence, TeachLanguage language) =>
        sentence.In(language).Split(' ', StringSplitOptions.RemoveEmptyEntries);

    private static readonly IReadOnlyList<ReorderItem> LanguageReorder =
    [
        new("language.sentences", 1, Text.Of("Put the words in the right order.|Pon las palabras en el orden correcto.|Mets les mots dans le bon ordre.|Posa les paraules en l'ordre correcte."),
            Text.Of("The cat is sleeping|El gato está durmiendo|Le chat dort|El gat dorm"),
            Text.Of("\"The cat is sleeping.\"|\"El gato está durmiendo.\"|« Le chat dort. »|\"El gat dorm.\"")),
        new("language.sentences", 2, Text.Of("Put the words in the right order.|Pon las palabras en el orden correcto.|Mets les mots dans le bon ordre.|Posa les paraules en l'ordre correcte."),
            Text.Of("She quickly closed the door|Ella cerró la puerta rápidamente|Elle a rapidement fermé la porte|Ella va tancar la porta ràpidament"),
            Text.Of("\"She quickly closed the door.\"|\"Ella cerró la puerta rápidamente.\"|« Elle a rapidement fermé la porte. »|\"Ella va tancar la porta ràpidament.\"")),
        new("language.sentences", 3, Text.Of("Put the words in the right order.|Pon las palabras en el orden correcto.|Mets les mots dans le bon ordre.|Posa les paraules en l'ordre correcte."),
            Text.Of("Although it was raining they went outside|Aunque estaba lloviendo salieron afuera|Bien qu'il pleuve ils sont sortis|Encara que plovia van sortir fora"),
            Text.Of("A sentence can start with \"although\" to show a contrast.|Una frase puede empezar con \"aunque\" para mostrar un contraste.|Une phrase peut commencer par « bien que » pour montrer un contraste.|Una frase pot començar amb \"encara que\" per mostrar un contrast.")),
    ];

    private static readonly (string Topic, int Difficulty, string[] English, string[] Spanish, Text Explanation)[] ForeignReorder =
    [
        ("foreign.sentences", 1, ["Good", "morning"], ["Buenos", "días"],
            Text.Of("A simple greeting.|Un saludo sencillo.|Une salutation simple.|Una salutació senzilla.")),
        ("foreign.sentences", 2, ["I", "am", "hungry"], ["Tengo", "mucha", "hambre"],
            Text.Of("A common everyday sentence.|Una frase habitual del día a día.|Une phrase courante du quotidien.|Una frase habitual del dia a dia.")),
        ("foreign.sentences", 3, ["Can", "you", "help", "me", "please"], ["Puedes", "ayudarme", "por", "favor"],
            Text.Of("A polite way to ask for help.|Una forma educada de pedir ayuda.|Une façon polie de demander de l'aide.|Una manera educada de demanar ajuda.")),
    ];

    private static readonly Text ForeignReorderPrompt =
        Text.Of("Put the {0} words in the right order.|Pon en orden las palabras en {0}.|Mets les mots en {0} dans le bon ordre.|Posa en ordre les paraules en {0}.");

    /// <summary>A word-reorder drill, or null if the bank has none for this subject/level.</summary>
    public static PracticeExercise? Reorder(Area area, Level level, TeachLanguage language, int seed)
    {
        var difficulty = DifficultyFor(level);
        if (area == Area.Language)
        {
            var pool = LanguageReorder.Where(i => i.Difficulty == difficulty).ToList();
            if (pool.Count == 0)
            {
                return null;
            }

            var item = pool[new Random(seed).Next(pool.Count)];
            var ordered = TokensOf(item.Sentence, language);
            return new PracticeExercise(item.Topic, item.Difficulty, ExerciseKind.Reorder, item.Prompt.In(language), item.Explanation.In(language))
            {
                Tokens = Shuffled(ordered, seed),
                CorrectOrder = ordered,
            };
        }

        if (area == Area.ForeignLanguage)
        {
            var pool = ForeignReorder.Where(i => i.Difficulty == difficulty).ToList();
            if (pool.Count == 0)
            {
                return null;
            }

            var item = pool[new Random(seed).Next(pool.Count)];
            var target = QuestionBanks.ForeignTarget(language);
            var ordered = (target == TeachLanguage.English ? item.English : item.Spanish).ToList();
            return new PracticeExercise(item.Topic, item.Difficulty, ExerciseKind.Reorder,
                ForeignReorderPrompt.Format(language, TargetName(language)), item.Explanation.In(language))
            {
                Tokens = Shuffled(ordered, seed),
                CorrectOrder = ordered,
            };
        }

        return null;
    }

    private sealed record MatchItem(string Topic, int Difficulty, Text Prompt, (Text Left, Text Right)[] Pairs, Text Explanation);

    private static readonly IReadOnlyList<MatchItem> LanguageMatch =
    [
        new("language.opposites", 1, Text.Of("Match each word with its opposite.|Relaciona cada palabra con su contrario.|Associe chaque mot à son contraire.|Relaciona cada paraula amb el seu contrari."),
            [
                (Text.Of("hot|caliente|chaud|calent"), Text.Of("cold|frío|froid|fred")),
                (Text.Of("big|grande|grand|gran"), Text.Of("small|pequeño|petit|petit")),
                (Text.Of("happy|feliz|heureux|feliç"), Text.Of("sad|triste|triste|trist")),
            ],
            Text.Of("Opposites: hot/cold, big/small, happy/sad.|Contrarios: caliente/frío, grande/pequeño, feliz/triste.|Contraires : chaud/froid, grand/petit, heureux/triste.|Contraris: calent/fred, gran/petit, feliç/trist.")),
        new("language.parts_of_speech", 2, Text.Of("Match each word with its part of speech.|Relaciona cada palabra con su categoría gramatical.|Associe chaque mot à sa catégorie grammaticale.|Relaciona cada paraula amb la seva categoria gramatical."),
            [
                (Text.Of("run|correr|courir|córrer"), Text.Of("verb|verbo|verbe|verb")),
                (Text.Of("blue|azul|bleu|blau"), Text.Of("adjective|adjetivo|adjectif|adjectiu")),
                (Text.Of("quickly|rápidamente|rapidement|ràpidament"), Text.Of("adverb|adverbio|adverbe|adverbi")),
            ],
            Text.Of("\"Run\" is a verb, \"blue\" an adjective, \"quickly\" an adverb.|\"Correr\" es un verbo, \"azul\" un adjetivo, \"rápidamente\" un adverbio.|« Courir » est un verbe, « bleu » un adjectif, « rapidement » un adverbe.|\"Córrer\" és un verb, \"blau\" un adjectiu, \"ràpidament\" un adverbi.")),
        new("language.literary_devices", 3, Text.Of("Match each device with its example.|Relaciona cada recurso con su ejemplo.|Associe chaque procédé à son exemple.|Relaciona cada recurs amb el seu exemple."),
            [
                (Text.Of("metaphor|metáfora|métaphore|metàfora"), Text.Of("Time is a thief.|El tiempo es un ladrón.|Le temps est un voleur.|El temps és un lladre.")),
                (Text.Of("simile|símil|comparaison|símil"), Text.Of("As brave as a lion.|Tan valiente como un león.|Aussi courageux qu'un lion.|Tan valent com un lleó.")),
                (Text.Of("personification|personificación|personnification|personificació"), Text.Of("The wind whispered.|El viento susurraba.|Le vent chuchotait.|El vent xiuxiuejava.")),
            ],
            Text.Of("A metaphor states one thing IS another; a simile compares with \"like\"/\"as\"; personification gives human traits to things.|Una metáfora dice que una cosa ES otra; un símil compara con \"como\"; la personificación da rasgos humanos a las cosas.|Une métaphore dit qu'une chose EST une autre ; une comparaison utilise « comme » ; la personnification donne des traits humains aux choses.|Una metàfora diu que una cosa ÉS una altra; un símil compara amb \"com\"; la personificació dona trets humans a les coses.")),
    ];

    private static readonly Dictionary<int, Text[]> ForeignMatchWords = new()
    {
        [1] = [Text.Of("cat|gato|chat|gat"), Text.Of("apple|manzana|pomme|poma"), Text.Of("sun|sol|soleil|sol")],
        [2] = [Text.Of("water|agua|eau|aigua"), Text.Of("book|libro|livre|llibre"), Text.Of("car|coche|voiture|cotxe")],
        [3] = [Text.Of("school|escuela|école|escola"), Text.Of("flower|flor|fleur|flor"), Text.Of("bread|pan|pain|pa")],
    };

    private static readonly Text ForeignMatchPrompt =
        Text.Of("Match each word with its translation in {0}.|Relaciona cada palabra con su traducción en {0}.|Associe chaque mot à sa traduction en {0}.|Relaciona cada paraula amb la seva traducció en {0}.");

    /// <summary>A matching-pairs drill, or null if the bank has none for this subject/level.</summary>
    public static PracticeExercise? Match(Area area, Level level, TeachLanguage language, int seed)
    {
        var difficulty = DifficultyFor(level);
        if (area == Area.Language)
        {
            var pool = LanguageMatch.Where(i => i.Difficulty == difficulty).ToList();
            if (pool.Count == 0)
            {
                return null;
            }

            var item = pool[new Random(seed).Next(pool.Count)];
            return new PracticeExercise(item.Topic, item.Difficulty, ExerciseKind.Match, item.Prompt.In(language), item.Explanation.In(language))
            {
                Pairs = item.Pairs.Select(p => new MatchPair(p.Left.In(language), p.Right.In(language))).ToList(),
            };
        }

        if (area == Area.ForeignLanguage)
        {
            if (!ForeignMatchWords.TryGetValue(difficulty, out var words))
            {
                return null;
            }

            var target = QuestionBanks.ForeignTarget(language);
            var explanation = Text.Of("");
            return new PracticeExercise("foreign.vocabulary", difficulty, ExerciseKind.Match,
                ForeignMatchPrompt.Format(language, TargetName(language)), explanation.In(language))
            {
                Pairs = words.Select(w => new MatchPair(w.In(language), w.In(target))).ToList(),
            };
        }

        return null;
    }

    /// <summary>Picks among fill-blank/reorder/match for Language/ForeignLanguage (the subjects without true/false
    /// content — task #71); null for any other subject or if this difficulty tier has no content of any of the 3
    /// kinds yet.</summary>
    private static readonly int[] DrillKindOrder = [0, 1, 2];

    public static PracticeExercise? LanguageDrill(Area area, Level level, TeachLanguage language, int seed)
    {
        if (area is not (Area.Language or Area.ForeignLanguage))
        {
            return null;
        }

        var rng = new Random(seed);
        var order = DrillKindOrder.OrderBy(_ => rng.Next()).ToArray();
        foreach (var pick in order)
        {
            var exercise = pick switch
            {
                0 => FillBlank(area, level, language, seed),
                1 => Reorder(area, level, language, seed),
                _ => Match(area, level, language, seed),
            };
            if (exercise is not null)
            {
                return exercise;
            }
        }

        return null;
    }
}
